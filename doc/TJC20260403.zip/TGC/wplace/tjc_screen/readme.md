串口屏 UI 菜单系统 - 说明文档

1. 项目简介

本项目是一个使用 C 语言实现的、模块化的 UI 菜单系统，专为通过串口（UART）控制的字符/图形显示屏设计。它基于状态机和驱动抽象层构建，具有高度的可移植性和可扩展性。

2. 核心架构

系统被设计为三个独立的层次，以实现“关注点分离”：

驱动抽象层 (Driver Layer)

文件: my_screen_driver.c, ui_menu_system.h (中的 display_driver_t)

职责: 封装所有与具体硬件（串口屏）通信的细节。

核心: display_driver_t 结构体。它是一个函数指针表（如 draw_text, clear），UI 逻辑层通过这个标准接口操作屏幕，而不关心底层的 write() 或指令集（0xFE 0xFD...）。

可移植性: 当您更换屏幕时（例如从 UART 屏换到 SPI OLED），您只需要重写 my_screen_driver.c 来实现新的 display_driver_t 实例。所有 UI 逻辑代码（.c 文件）都无需改动。

UI 逻辑层 (State Machine Layer)

文件: ui_state_*.c (例如 ui_state_main.c, ui_state_network.c 等)

职责: 定义每一个独立的屏幕界面或菜单。

核心: ui_state_t 结构体。每个“状态”都必须实现两个关键函数：

on_enter(manager): 当进入此状态时调用，负责绘制当前界面。

handle_input(manager, event): 当此状态下发生按键时调用，负责处理逻辑（例如切换到新状态、修改数据）。

UI 管理器 (Manager Layer)

文件: ui_menu_system.c, main.c

职责: 作为“胶水”将所有部分粘合在一起。

核心: ui_manager_t 结构体。它持有：

display: 指向当前注册的驱动。

current_state: 指向当前激活的UI状态。

user_data: 一个 void* 指针，指向您的全局应用数据。

应用数据层 (Data Layer)

文件: app_data.h, main.c

职责: 定义和存储设备的所有配置和状态。

核心: app_config_t 结构体。UI 模块本身不拥有这份数据，它只是通过 manager->user_data 指针来读取（例如显示 IP）或修改（例如设置 current_status）这份数据。

3. 文件结构说明

.
├── Makefile                # (Linux) 编译器
├── app_data.h              # [数据] 定义全局 app_config_t 结构体
├── main.c                  # [应用] 程序入口, 初始化, 按键模拟, 主循环
│
├── ui_menu_system.h        # [框架-核心] 定义 display_driver_t, ui_state_t, ui_manager_t
├── ui_menu_system.c        # [框架-核心] 实现 ui_init(), ui_handle_input(), ui_set_state()
│
├── my_screen_driver.h      # [驱动-接口] 暴露 get_my_screen_driver()
├── my_screen_driver.c      # [驱动-实现] 硬件串口操作, 封装 0xFE 0xFD... 指令集
│
├── ui_state_main.h         # [状态-上电]
├── ui_state_main.c         # [状态-上电] "上电" 界面 (显示 IP, Status 等)
│
├── ui_state_menu_list.h    # [状态-主菜单]
├── ui_state_menu_list.c    # [状态-主菜单] 包含 "Device Info", "Network" 等的列表
│
├── ui_state_device_info.h  # [状态-设备]
├── ui_state_device_info.c  # [状态-设备] "Device Info" 菜单 (包含内部状态：列表/只读)
│
├── ui_state_network.h      # [状态-网络]
├── ui_state_network.c      # [状态-网络] "Network Setting" 菜单 (最复杂的状态)
│
├── ui_state_lock.h         # [状态-密码]
├── ui_state_lock.c         # [状态-密码] "LockPasswd" 只读界面
│
├── ui_state_restart.h      # [状态-重启]
├── ui_state_restart.c      # [状态-重启] "Restart?" Yes/No 确认界面
│
└── ui_state_factory_reset.h # [状态-重置]
└── ui_state_factory_reset.c # [状态-重置] "Factory Reset?" Yes/No 确认界面


4. 关键功能实现

内部状态机 (以 ui_state_network.c 为例)

ui_state_network.c 是一个“状态中的状态”。它内部定义了一个 net_mode_t 来管理自己是处于：

NET_MODE_LAN_SELECT (LAN1/LAN2 选择列表)

NET_MODE_SETTINGS_LIST (设置项列表)

NET_MODE_DISPLAY_ITEM (只读显示, 如 MAC 地址)

NET_MODE_EDIT_IP_CONFIG (DHCP/Static 编辑)

NET_MODE_EDIT_IP_GENERIC (IP 地址数字编辑)

所有的绘制和按键处理都会首先检查 current_mode 来决定执行哪个逻辑。

多网口支持 (NUM_LAN_PORTS)

在 ui_state_network.c 和 ui_state_main.c 中，使用 C 预处理器 #if (NUM_LAN_PORTS > 1) 来在编译时动态更改 UI 布局（例如显示1个或2个IP地址）。

IP 编辑器与刷新优化

编辑逻辑: 在 NET_MODE_EDIT_IP_GENERIC 模式下，edit_buffer 存储当前 IP 字符串，edit_cursor_pos 跟踪要高亮的字符索引。

按键 (Up/Down): 只修改 edit_buffer 中的字符，并调用 refresh_edit_ip_generic_char()。此函数只重绘那个被高亮的字符，不清除屏幕，实现无闪烁修改。

按键 (Confirm): 调用 draw_edit_ip_generic_page_full() 重新绘制整个 IP 编辑器界面，确保所有元素正确显示，包括新的光标位置高亮。

配置修改与重启逻辑

修改: 当用户在 ui_state_network.c 中修改了任何数据（如 IP 地址或 DHCP/Static），app_config_t 中的 current_status 会被设置为 STATUS_REBOOT_REQUIRED。

退出: 当用户从 ui_state_network.c 退出时，handle_input 会检查 current_status。

跳转: 如果是 STATUS_REBOOT_REQUIRED，程序强制跳转到 g_state_restart（重启确认界面）。

确认:

如果用户选 "Yes"，ui_state_restart.c 会清除状态标志（config->current_status = STATUS_NORMAL），然后执行重启。

如果用户选 "No"，标志不会被清除，程序返回主菜单。

提示:

ui_state_menu_list.c（主菜单）的 on_enter 不会显示警告。

ui_state_main.c（上电界面）的 on_enter 会检查 current_status，并在状态行显示 "Reboot"，以此作为持续的重启提示。

5. 编译与测试 (Linux)

编译: 在项目根目录运行 make。

运行: ./ui_test (或 sudo ./ui_test，如果需要串口权限)。

测试: 程序启动后，在终端中按以下按键模拟输入：

m: 菜单 (Menu / Back)

u: 上 (Up)

d: 下 (Down)

c: 确认 (Confirm / OK)