/* * main.c (示例)  屏幕充电口朝右为正
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>  // 用于 usleep
#include <termios.h> // 用于 termios
#include <signal.h>  // 用于 signal

#include "ui_menu_system.h"
#include "my_screen_driver.h" // 您的驱动
#include "app_data.h"         // 您的数据
#include "ui_state_main.h"    // 您的第一个状态

// 1. 定义您的全局UI管理器
ui_manager_t g_ui_manager;

// 2. 定义您的全局应用数据
app_config_t g_app_data;

// 3. 填充您的应用数据 (示例)
void load_app_data(void)
{
    printf("MAIN: App data loaded.\n");
    
    // --- [修改] 通用设置 ---
    strcpy(g_app_data.model_name, "QPort1255");
    strcpy(g_app_data.model, "QPort1255"); //
    
    // --- [修改] 状态 ---
    g_app_data.current_status = STATUS_NORMAL; // e.g., Start in Lock state
    g_app_data.error_code = 1; // 仅在 STATUS_ERROR 时显示

    
    // [Device Info]
    strcpy(g_app_data.firmware_version, "V1.1.2");
    strcpy(g_app_data.serial_number, "20250501000001");

    // [Lock Password]
    strcpy(g_app_data.lock_password, "123456");
    
    // --- 网络数据 ---
    // --- LAN 1 (索引 0) ---
    strcpy(g_app_data.lan_ports[0].ethernet_status, "100M/Link");
    strcpy(g_app_data.lan_ports[0].mac_address, "00:11:22:AA:BB:CC");
    strcpy(g_app_data.lan_ports[0].ip_address, "192.168.255.123");
    strcpy(g_app_data.lan_ports[0].network_mask, "255.255.255.0");
    strcpy(g_app_data.lan_ports[0].gateway, "192.168.0.1");
    g_app_data.lan_ports[0].ip_config = IP_CONFIG_STATIC; // [修改]

    // --- LAN 2 (索引 1) ---
    strcpy(g_app_data.lan_ports[1].ethernet_status, "No Link");
    strcpy(g_app_data.lan_ports[1].mac_address, "00:11:22:DD:EE:FF");
    strcpy(g_app_data.lan_ports[1].ip_address, "192.168.1.123");
    strcpy(g_app_data.lan_ports[1].network_mask, "255.255.255.0");
    strcpy(g_app_data.lan_ports[1].gateway, "192.168.1.1");
    g_app_data.lan_ports[1].ip_config = IP_CONFIG_DHCP; // [修改]
}

// --- 信号处理，用于安全退出 ---
volatile sig_atomic_t g_running = 1;
void sigint_handler(int sig) {
    (void)sig;
    g_running = 0;
}

// --- Linux 终端按键模拟 ---
static key_event_t my_keypad_get_event(void) {
    struct termios oldt, newt;
    int ch;
    
    // 1. 设置终端为非规范模式
    tcgetattr(STDIN_FILENO, &oldt);
    newt = oldt;
    newt.c_lflag &= ~(ICANON | ECHO);
    tcsetattr(STDIN_FILENO, TCSANOW, &newt);

    // 2. (非阻塞) 检查是否有按键
    // (为了简单，我们用阻塞式 read)
    printf("\n(m=Menu, u=Up, d=Down, c=Confirm) -> ");
    ch = getchar();
    
    // 3. 恢复终端
    tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
    
    // 4. 映射
    switch(ch) {
        case 'm': return KEY_EVENT_MENU;
        case 'u': return KEY_EVENT_UP;
        case 'd': return KEY_EVENT_DOWN;
        case 'c': return KEY_EVENT_CONFIRM;
        default:  return KEY_EVENT_NONE;
    }
}


int main(void)
{
    my_screen_rotate();
    printf("=== UI System Test Start ===\n");
    
    // 注册 Ctrl+C 信号处理器
    signal(SIGINT, sigint_handler);

    // 1. 加载或初始化您的配置数据
    load_app_data();

    // 2. 初始化UI模块
    ui_init(
        &g_ui_manager,                 // UI管理器实例
        get_my_screen_driver(),        // 您实现的屏幕驱动
        &g_app_data,                   // 指向您的应用数据
        &g_state_main                  // 告诉UI从“上电状态”开始
    );
    
    printf("MAIN: UI Initialized. Current state: 'g_state_main'\n");
    printf("\n=== Entering interactive test loop ===\n");

    
    
    // ... (在您的主循环中) ...
    while (g_running)
    {
        // 1. 检测按键 (Linux 模拟)
        key_event_t event = my_keypad_get_event(); 
        
        // 2. 将按键推送给UI模块
        if (event != KEY_EVENT_NONE) {
            ui_handle_input(&g_ui_manager, event);
        }
        
        // 3. (如果您的数据会动态变化，例如网络状态)
        // if (network_status_changed()) {
        //     update_app_data_status(); // 更新 g_app_data
        //     ui_refresh(&g_ui_manager);  // 通知UI重绘
        // }
    }
    
    // --- 退出 ---
    printf("\n=== UI System Test End ===\n");
    printf("MAIN: Cleaning up driver...\n");
    // 关闭串口
    const display_driver_t* drv = get_my_screen_driver();
    if (drv->clear) {
        drv->clear();
    }
    
    // 恢复终端
    struct termios oldt;
    tcgetattr(STDIN_FILENO, &oldt);
    oldt.c_lflag |= (ICANON | ECHO);
    tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
    
    return 0;
}

